#include "Arduino.h"
void blinkLED(int pin, int delayTime);
void fadeLED(int pin, int brightness, int fadeAmount);